from gossip import GossipProtocol
import timeit
port = 5222
listNodes = list(range(900)) # change the number of nodes in topology
connected_nodes = listNodes 
Dict = dict.fromkeys(listNodes,0) 
start = timeit.default_timer()
node = GossipProtocol(port)
stop = timeit.default_timer()
print('Time: ', (stop - start) *1000) # Calculate convergence time
