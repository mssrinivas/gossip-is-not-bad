import random
import socket 
from threading import Thread
import time
from enum import Enum
import sys
import timeit
import math

class GossipProtocol:
    infected_nodes = []  # list to carry infected_nodes
    topology = "full" # topoplogy 
    message = "gossip_message" # message to be sent
    listNodes = [1234,3456,7899,7543]  # maintains the list of nodes
    connected_nodes = [1234,3456,7899,7543] 
    Dict = dict([(1234, 0), (3456, 0), (7899, 0), (7543, 0)]) # maps the message state for the message
    sys.setrecursionlimit(200000) 

    def __init__(self, port): 
        self.node = socket.socket(type=socket.SOCK_DGRAM)  # create connectionless UDP protocol
        self.hostname = socket.gethostname() 
        self.port = port 
        self.node.bind((self.hostname, self.port)) 
        self.susceptible_nodes = self.listNodes 
        self.start = timeit.default_timer() # start the timer for the program
        self.listNodes = list(range(100))  #intializing number of nodes to 100
        self.Dict = dict.fromkeys(self.listNodes,0) 
        self.connected_nodes = self.listNodes
        self.sendRumor(0,self.listNodes, self.topology)  # Start rumor at pid 0

    def input_message(self): 
        message_to_send = "message"

    def receive_message(self): 
        while True: 
            message_to_forward, address = self.node.recvfrom(1024) 

    def transmit_message(self, selectedport, listNodes, topology):
        selected_port = selectedport
        message = self.message.encode('ascii')
        self.node.sendto(message, (self.hostname, selected_port))
        if selected_port in self.Dict: 
          if self.Dict[selectedport]<=10:
            if self.Dict[selectedport] == 10:
              # if state of message is 10 for a particular node then calculate convergence and exit accordingly            
              self.listNodes.remove(selected_port) 
              self.Dict.pop(selected_port, None) 
              numDeadProcess = len(self.connected_nodes) - len(self.listNodes)
              numNodes = len(self.connected_nodes)
              pctNumDeadProcess = ((numDeadProcess) * 100) 
              pctNumDeadProcess = pctNumDeadProcess / numNodes 
              if pctNumDeadProcess >= 75: 
                stop = timeit.default_timer() 
                print('Time: ', (stop - self.start) *1000) 
                sys.exit()
              else: 
                if selected_port in self.Dict:
                  self.Dict[selected_port] = self.Dict.get(selected_port) + 1 
                  self.sendRumor(selected_port, listNodes, topology) # update message state and continue spread
            else: 
              if selected_port in self.Dict:
                self.Dict[selected_port] = self.Dict.get(selected_port) + 1 # update message state and continue spread

    def fetchRandNeigh(self, pid, listNodes, topology): 
      # find different neighbours for line topology
        if topology == "line" :
            if pid!=None and pid>=0: 
              if listNodes[0] == pid : 
                  neigh_pid = listNodes[1] 
                  return neigh_pid
              elif listNodes[len(listNodes)-1] == pid :
                  neigh_pid = listNodes[len(listNodes)-2]
                  return neigh_pid 
              else: 
                  rand_val = random.choice([-1,1])
                  n_idx = pid + rand_val 
                  neigh_pid = n_idx
                  return neigh_pid
        # find different neighbours for full topology
        elif topology == "full": 
             GossipProtocol.infected_nodes.append(pid) 
             self.listNodes.remove(pid) 
             self.Dict.pop(pid, None)
             self.Dict.pop(pid, None) 
             neigh_pid = random.choice(listNodes)
             return neigh_pid
        # find different neighbours for 2D topology
        elif topology == "2D": 
            if pid in self.listNodes and len(self.listNodes)>1:
              numNodes = len(self.listNodes) 
              n = round(float(math.floor(math.sqrt(numNodes)))) 
              pid_idx = pid 
              rowNum = round(float(math.floor(pid_idx/n))) 
              colNum = pid_idx%n 
              neighbours = [] 
              if rowNum == 0 or rowNum == n-1: 
                if colNum == 0 or colNum == n-1: 
                  x = n - 1 
                  if rowNum == 0 and colNum == 0: 
                    neighbours = [[0,1], [1,0]] 
                  elif rowNum == x and colNum == x: 
                    neighbours = [[x, x-1], [x-1, x]] 
                  elif rowNum == 0 and colNum == x : 
                    neighbours = [[0, x-1], [1, x]] 
                  elif rowNum == x and colNum == 0 :
                    neighbours = [[x-1, 0], [x, 1]]
                  rand_neighbour = random.choice(neighbours) 
                  randRow = rand_neighbour[0] 
                  randCol = rand_neighbour[1] 
                  neighbour_index = n * randRow + randCol
                  neigh_pid = neighbour_index
                  return neigh_pid
                else: 
                  x = n - 1 
                  if rowNum == 0: 
                    neighbours = [[0,colNum-1], [0, colNum+1], [1, colNum]]
                  elif rowNum == x : 
                    neighbours = [[x,colNum-1], [x, colNum+1], [x-1, colNum]] 
                  
                  rand_neighbour = random.choice(neighbours) 
                  randRow = rand_neighbour[0] 
                  randCol = rand_neighbour[1] 
                  neighbour_index = n * randRow + randCol
                  neigh_pid = neighbour_index
                  
                  return neigh_pid
              else: 
                  if colNum == 0 or colNum == n-1 : 
                    x = n - 1
                    if colNum == 0 :
                      neighbours = [[rowNum-1,0], [rowNum+1, 0], [rowNum, 1]] 
                    elif colNum == x : 
                      neighbours = [[rowNum-1,x], [rowNum+1, x], [rowNum, x-1]] 
                    rand_neighbour = random.choice(neighbours) 
                    randRow = rand_neighbour[0] 
                    randCol = rand_neighbour[1] 
                    neighbour_index = n * randRow + randCol
                    neigh_pid = neighbour_index
                    return neigh_pid
                  else: 
                    x = n - 1 
                    neighbours = [[rowNum-1,colNum], [rowNum+1, colNum], [rowNum, colNum-1], [rowNum, colNum+1]]
                    rand_neighbour = random.choice(neighbours) 
                    randRow = rand_neighbour[0] 
                    randCol = rand_neighbour[1] 
                    neighbour_index = n * randRow + randCol
                    neigh_pid = neighbour_index
                    return neigh_pid
            
  # Exhaustive recurssive call      
    def sendRumor(self, pid, listNodes, topology): 
        if len(self.listNodes) <= 1 and len(self.Dict) <=1 :
             return 
        else: 
            neigh_pid = self.fetchRandNeigh(pid, listNodes, topology)
            self.transmit_message(neigh_pid,listNodes, topology) 
            self.sendRumor(neigh_pid,listNodes, topology)
